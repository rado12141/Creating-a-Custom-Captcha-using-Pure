/**
 * Element Selectors
 */
const captchaTextField = document.querySelector(".captcha-text-field")
const refreshBTN = document.querySelector(".reload-btn")
const inputField = document.querySelector(".chaptcha-input input")
const confirmBTN = document.querySelector(".confirm-btn")
const msgField = document.querySelector(".msg-field")

// Characters for Generating Captcha
let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXDabcdefghijklmnopqrstuvwxyz1234567890';
// converting characters to array
let charArr = chars.split('');

function generateCaptcha(){
    //Generate Captcha Characters
    for (let i = 0; i < 6; i++) { 
        let randomCharacter = charArr[Math.floor(Math.random() * charArr.length)];
        // Display generated captcah to textfield
        captchaTextField.innerText += ` ${randomCharacter}`; 
    }
}
// Reset Captacha Content
function resetCaptchaContent(){
    inputField.value = "";
    captchaTextField.innerText = "";
    msgField.style.display = "none";
}

// Trigger Generate Captcha
generateCaptcha(); 

// Regenerate Captcha Code or Characters
refreshBTN.addEventListener("click", ()=>{
  resetCaptchaContent();
  generateCaptcha();
});

// Confirm if entered captcah value matches the generated captcha
confirmBTN.addEventListener("click", e =>{
  e.preventDefault(); 
  let inputVal = inputField.value;
  if(inputVal == captchaTextField.innerText.split(' ').join('')){ 
    msgField.style.color = "#7AA874";
    msgField.innerText = "Captcha Confirmed";
    // Reset Captcha Field After 3 secods
    setTimeout(()=>{
      resetCaptchaContent();
      generateCaptcha();
    }, 3000);
  }else{
    msgField.style.color = "#ED2B2A";
    msgField.innerText = "Entered Captcha Value does not matched. Please try again!";
  }
  msgField.style.display = "block";
});
